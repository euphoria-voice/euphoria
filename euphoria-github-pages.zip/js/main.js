const byId = id => document.getElementById(id);
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const gate = byId('gate');
gate.showModal();
const boot = byId('boot');
const progress = byId('boot-progress');
const poster = byId('keyvisual');
let bootFrame;
let posterReady = poster.complete;
const bootStart = performance.now();
function endBoot() {
  cancelAnimationFrame(bootFrame);
  boot.hidden = true;
}
function updateBoot(now) {
  const elapsed = now - bootStart;
  progress.value = Math.min(posterReady ? 100 : 94, elapsed / 7);
  if ((posterReady && progress.value === 100) || elapsed > 2500) endBoot();
  else bootFrame = requestAnimationFrame(updateBoot);
}
poster.addEventListener('load', () => {posterReady=true;});
byId('skip').onclick = () => {endBoot(); enterPalace(true);};
if (reducedMotion.matches) endBoot();
else bootFrame = requestAnimationFrame(updateBoot);
const music = byId('palace-music');
const clockwork = byId('door-sound');
const soundSwitch = byId('sound-switch');
let soundEnabled = true;
let entered = false;
try { soundEnabled = localStorage.getItem('euphoria.sound') !== 'off'; } catch {}
function showSoundState() {
  const playing = !music.paused && soundEnabled;
  soundSwitch.textContent = playing ? '♫ ON' : '♫ OFF';
  soundSwitch.setAttribute('aria-pressed', String(playing));
}
music.addEventListener('play', showSoundState);
music.addEventListener('pause', showSoundState);
function playMusic() {
  music.play().catch(showSoundState);
}
soundSwitch.addEventListener('click', () => {
  soundEnabled = music.paused;
  if (soundEnabled) playMusic();
  else { music.pause(); clockwork.pause(); }
  try { localStorage.setItem('euphoria.sound', soundEnabled ? 'on' : 'off'); } catch {}
  showSoundState();
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { music.pause(); clockwork.pause(); }
  else if (entered && soundEnabled) playMusic();
});
function enterPalace(skip = false) {
  endBoot();
  if (entered) return;
  if (!location.hash) window.scrollTo({top:0,behavior:"instant"});
  entered = true;
  const immediate = skip === true || reducedMotion.matches;
  if (!immediate) gate.classList.add('winding');
  if (soundEnabled) {
    if (!immediate) clockwork.play().catch(() => {});
    playMusic();
  }
  function openDoors() {
    clockwork.pause();
    gate.classList.add('opening');
    setTimeout(() => {
      gate.close();
      byId('home').classList.add('arrived');
      byId('home').focus({preventScroll:true});
    }, immediate ? 0 : 1450);
  }
  if (immediate) openDoors();
  else setTimeout(openDoors, 1400);
}
byId('enter').onclick = enterPalace;
gate.oncancel = event => {event.preventDefault(); enterPalace();};
function setMenu(open) {
  byId('menu').setAttribute('aria-expanded', String(open));
  byId('nav').classList.toggle('open', open);
}
byId('menu').onclick = () => setMenu(!byId('nav').classList.contains('open'));
byId('nav').onclick = () => setMenu(false);
document.addEventListener('keydown', event => {if (event.key === 'Escape') setMenu(false);});
const viewer = byId('viewer');
viewer.querySelector('.close').onclick = () => viewer.close();
viewer.onclick = event => {
  if (event.target === viewer) {
    const rect = viewer.getBoundingClientRect();
    if(event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) viewer.close();
  }
};
function element(tag, value, className) {
  const node = document.createElement(tag);
  if(value) node.textContent = value;
  if(className) node.className = className;
  return node;
}
function image(src, alt) {
  const node = element('img');
  node.loading = 'lazy';
  node.src = src;
  node.alt = alt;
  return node;
}
function inspect(src,title,person) {
  byId('full').src=src;
  byId('full').alt=title;
  byId('viewer-title').textContent=title;
  const bio=byId('bio');
  bio.replaceChildren();
  if(person) {
    for(const [label,value] of [['',person.introduction],['声の特徴　',person.voice],['プロフィール　',person.profile]]) {
      if(value) bio.append(element('p',label+value));
    }
    if(/^https?:\/\//i.test(person.sns)) {
      const a=element('a','SNSを見る'); a.href=person.sns; a.target='_blank'; a.rel='noopener noreferrer'; bio.append(a);
    }
  }
  viewer.showModal();
}
function castPortrait(person,title,groupLabel) {
  const panel = element('article','','owner-portrait');
  panel.dataset.group = person.group;
  const large = image(person.standing || person.portrait,title+'の肖像');
  const art = element('div','','owner-art');
  art.classList.toggle('full-length', Boolean(person.standing));
  art.append(large);
  const info = element('div','','owner-info');
  const options = element('div','','pose-options');
  options.setAttribute('role','group');
  options.setAttribute('aria-label',title+'のポーズを選ぶ');
  for(const [pose,label] of person.poses || []) {
    const src = 'images/cast/'+person.posePrefix+'-'+pose+'.webp';
    const choice = element('button','','pose-'+pose);
    choice.setAttribute('aria-label',label+'のポーズ');
    choice.setAttribute('aria-pressed',String(src===person.standing));
    choice.append(image(src.replace('.webp','-face.webp'),''),element('span',label));
    choice.onclick = () => {
      art.classList.toggle('full-length', person.posePrefix !== 'asahina' || src === person.standing);
      large.src = src;
      large.alt = title+'の'+label+'ポーズ';
      for(const other of options.children) other.setAttribute('aria-pressed',String(other===choice));
    };
    options.append(choice);
  }
  const heading = element('h4',title);
  heading.id = 'cast-detail-title';
  info.append(element('span',person.role || groupLabel,'owner-role'),heading);
  if(person.roman) info.append(element('i',person.roman,'owner-roman'));
  for(const value of [person.introduction,person.voice,person.profile]) {
    if(value) info.append(element('p',value));
  }
  if(person.poses) info.append(options);
  const links = element('div','','cast-socials');
  const entries = [['X',person.x],['ファングループ',person.fanGroup],['SNSを見る',person.sns]];
  for(const [label,url] of entries) {
    if(!/^https?:\/\//i.test(url)) continue;
    const link = element('a',label);
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.setAttribute('aria-label',title+'の'+label);
    links.append(link);
  }
  if(links.childElementCount) info.append(links);
  panel.append(art,info);
  return panel;
}
const castGroups = {princess:'女性キャスト', prince:'男性キャスト'};
const selectedMember = {princess:0, prince:0};
const roster = byId('portraits');
const castPrev = byId('cast-prev');
const castNext = byId('cast-next');
function updateCastArrows() {
  castPrev.disabled = roster.scrollLeft <= 1;
  castNext.disabled = roster.scrollWidth - roster.clientWidth - roster.scrollLeft <= 1;
}
for(const [button,direction] of [[castPrev,-1],[castNext,1]]) {
  button.onclick = () => roster.scrollBy({
    left:direction * roster.clientWidth,
    behavior:reducedMotion.matches ? 'instant' : 'smooth'
  });
}
roster.addEventListener('scroll',updateCastArrows,{passive:true});
new ResizeObserver(updateCastArrows).observe(roster);
function showCastGroup(group) {
  const people = palaceContent.cast.filter(person => person.group === group);
  const label = castGroups[group];
  roster.replaceChildren();
  for(const key of Object.keys(castGroups)) {
    byId(key+'-cast').setAttribute('aria-pressed',String(key === group));
  }
  people.forEach((person,index) => {
    const title = person.name || person.displayTitle || person.role || label+'の肖像 '+(index+1);
    const button = element('button','','portrait');
    button.setAttribute('aria-label',title);
    button.setAttribute('aria-controls','profile-body');
    button.setAttribute('aria-pressed','false');
    button.append(image(person.icon ? person.icon + '?v=2' : person.portrait,''));
    button.onclick = () => {
      selectedMember[group] = index;
      for(const item of roster.children) item.setAttribute('aria-pressed',String(item === button));
      byId('profile-body').replaceChildren(castPortrait(person,title,label));
    };
    roster.append(button);
  });
  roster.children[selectedMember[group]]?.click();
  roster.scrollLeft = 0;
  updateCastArrows();
}
for(const group of Object.keys(castGroups)) {
  byId(group+'-cast').onclick = () => showCastGroup(group);
}
showCastGroup(location.hash === '#prince-cast' ? 'prince' : 'princess');
const orbit = byId('memories');
const cards = palaceContent.gallery.map(item => {
  const card = element('button');
  card.append(image(item.image,item.title));
  card.onclick = () => inspect(item.image,item.title);
  orbit.append(card);
  return card;
});
let phase = 0;
let playing = !reducedMotion.matches;
let frame = 0;
let visible = false;
let previousTime = 0;
function arrange() {
  cards.forEach((card,index) => {
    const angle = index * 2 * Math.PI / cards.length - phase;
    const depth = (1 + Math.cos(angle)) / 2;
    const x = Math.sin(angle) * orbit.clientWidth * .31;
    card.style.transform = 'translate(-50%, -50%) translate('+x+'px,'+((depth-.5)*45)+'px) scale('+(.56+.44*depth)+')';
    card.style.zIndex = String(Math.round(depth * 1000));
  });
}
function tick(time) {
  if(previousTime) phase += Math.min(time-previousTime,100) * 2*Math.PI/48000;
  previousTime = time;
  arrange();
  frame = requestAnimationFrame(tick);
}
function syncOrbit() {
  cancelAnimationFrame(frame);
  previousTime = 0;
  byId('memory-play').textContent = playing ? '回転を止める' : '回転を再開';
  if(playing && visible && !document.hidden && !viewer.open && !gate.open) frame=requestAnimationFrame(tick);
}
function step(direction) {
  if(!cards.length) return;
  playing=false;
  const spacing=2*Math.PI/cards.length;
  phase=(Math.round(phase/spacing)+direction)*spacing;
  arrange();
  syncOrbit();
}
byId('memory-prev').onclick=()=>step(-1);
byId('memory-next').onclick=()=>step(1);
byId('memory-play').onclick=()=>{playing=!playing;syncOrbit();};
new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;syncOrbit();}).observe(orbit);
new ResizeObserver(arrange).observe(orbit);
new MutationObserver(syncOrbit).observe(viewer,{attributes:true,attributeFilter:['open']});
gate.addEventListener('close',syncOrbit);
document.addEventListener('visibilitychange',syncOrbit);
reducedMotion.addEventListener('change',()=>{playing=!reducedMotion.matches;syncOrbit();});
arrange();
syncOrbit();
document.querySelector('[data-photo]').onclick = event => inspect(event.currentTarget.dataset.photo,'王宮の集合ポスター');
for(const item of [...palaceContent.news].sort((a,b)=>b.date.localeCompare(a.date))) {
  const row=element('article','','news-row');
  const time=element('time',item.date.replaceAll('-','.'));time.dateTime=item.date;
  row.append(time,element('span',item.category,'category'));
  const age=Date.now()-Date.parse(item.date+'T00:00:00+09:00');
  if(age>=0 && age<14*86400000) row.append(element('b','NEW'));
  row.append(element('p',item.title));
  byId('newslist').append(row);
}
if('IntersectionObserver' in window && !reducedMotion.matches) {
  const observer = new IntersectionObserver(entries => {
    for(const entry of entries) {
      if(entry.isIntersecting) {
        entry.target.classList.remove('await-scroll');
        observer.unobserve(entry.target);
      }
    }
  },{threshold:0});
  for(const block of document.querySelectorAll('.ribbon-stage,.chapter>h2,.chapter>p,.chapter>.seal,#newslist,.scenes article,.cast-group>*,#agenda,.rest-slider,.memory-orbit,.orbit-controls,#guide details,.contact-links,footer')) {
    block.classList.add('scroll-block','await-scroll');
    observer.observe(block);
  }
}

// Paint the rear half first so the satin loop passes behind itself.
{
  const canvas = document.getElementById('welcome-loop');
  const logo = document.getElementById('ribbon-logo');
  const ctx = canvas.getContext('2d');
  let phase = 0, last = 0, frame = 0, visible = false;
  function draw(now) {
    frame = 0;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    const ratio = Math.min(devicePixelRatio || 1, 2);
    if(canvas.width !== Math.round(w*ratio) || canvas.height !== Math.round(h*ratio)){
      canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);
    }
    ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,w,h);
    if(last && !reducedMotion.matches) phase=(phase+Math.min(now-last,80)*0.000105)%(2*Math.PI);
    last=now;
    const rx=w*.465, ry=h*.20, thickness=h*.40;
    function point(angle,edge) {
      return [w/2+rx*Math.cos(angle), h*.5+ry*Math.sin(angle)-h*.075*Math.cos(angle)+edge*thickness*(.82+.18*Math.sin(angle))];
    }
    for(const front of [false,true]){
      const start=front?0:Math.PI,end=start+Math.PI;
      const grad=ctx.createLinearGradient(0,h*.25,0,h*.77);
      (front?['#e9cbe8','#fff4fa','#e4f4ff','#bbd6ee']:['#a3bbda','#cbcae3','#eed5e6','#bdd6ed']).forEach((c,i)=>grad.addColorStop(i/3,c));
      ctx.fillStyle=grad;ctx.beginPath();
      for(let j=0;j<=90;j++){const p=point(start+j*Math.PI/90,-.5);j?ctx.lineTo(...p):ctx.moveTo(...p);}
      for(let j=90;j>=0;j--)ctx.lineTo(...point(start+j*Math.PI/90,.5));
      ctx.closePath();ctx.fill();
      for(const edge of [-.46,.46]){ctx.beginPath();for(let j=0;j<=90;j++){const p=point(start+j*Math.PI/90,edge);j?ctx.lineTo(...p):ctx.moveTo(...p);}ctx.strokeStyle='#fff8fa';ctx.lineWidth=2;ctx.stroke();}
      const repeats=w<620?6:10;
      for(let n=0;n<repeats;n++){
        const a=(phase+2*Math.PI*n/repeats)%(2*Math.PI);
        if(a<start || a>=end)continue;
        const [x,y]=point(a,0),f=Math.sin(a);
        ctx.save();ctx.translate(x,y);ctx.scale(Math.abs(f),1);
        if(front){const height=Math.min(thickness*.95,w*.84/repeats*logo.naturalHeight/logo.naturalWidth*2);ctx.drawImage(logo,-height*logo.naturalWidth/logo.naturalHeight/2,-height/2,height*logo.naturalWidth/logo.naturalHeight,height);}
        else {ctx.fillStyle='#ffffffb8';ctx.textAlign='center';ctx.font='16px Georgia';ctx.fillText('✧',0,5);}
        ctx.restore();
      }
    }
    if(visible && !document.hidden && !reducedMotion.matches)frame=requestAnimationFrame(draw);
  }
  function refresh(){cancelAnimationFrame(frame);last=0;if(visible&&!document.hidden)frame=requestAnimationFrame(draw);}
  function start(){if(!ctx||!logo.naturalWidth)return;canvas.parentElement.classList.add('ready');new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;refresh();}).observe(canvas);new ResizeObserver(refresh).observe(canvas);reducedMotion.addEventListener('change',refresh);document.addEventListener('visibilitychange',refresh);}
  if(logo.complete)start();else logo.addEventListener('load',start,{once:true});
}

const teaPetals = document.querySelector('.tea-petals');
const petalPositions = [4,92,15,86,8,97,21,80,2,89,12,95,18,83];
petalPositions.forEach((left,index)=>{
  const petal = document.createElement('i');
  const style = petal.style;
  style.setProperty('--left',left+'%');
  style.setProperty('--size',(7+index%5*1.4)+'px');
  style.setProperty('--duration',(13+index%6*1.7)+'s');
  style.setProperty('--delay',-(2+index*7.31)+'s');
  style.setProperty('--flutter',(2.4+index%4*.62)+'s');
  style.setProperty('--drift',(index%2?-1:1)*(10+index%4*4)+'px');
  teaPetals.append(petal);
});

const videoTrack = byId('video-track');
const videoSlides = Array.from(videoTrack.children);
function videoIndex() {
  const stride = videoSlides[1].offsetLeft - videoSlides[0].offsetLeft;
  return Math.max(0, Math.min(videoSlides.length-1, Math.round(videoTrack.scrollLeft / stride)));
}
function moveVideo(direction) {
  const index = (videoIndex() + direction + videoSlides.length) % videoSlides.length;
  videoTrack.scrollTo({left:videoSlides[index].offsetLeft,behavior:reducedMotion.matches?'instant':'smooth'});
}
videoTrack.addEventListener('scroll', () => {
  const count = (videoIndex()+1)+' / '+videoSlides.length;
  if(byId('video-position').textContent !== count) byId('video-position').textContent = count;
},{passive:true});
byId('video-prev').onclick = () => moveVideo(-1);
byId('video-next').onclick = () => moveVideo(1);
