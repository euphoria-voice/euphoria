// group は princess / prince。紹介・SNSは本人確認後に記入してください。
const profiles = [
  [30,1,'オーナー'], [24,2], [33,3], [1,4], [9,5], [18,6], [10,7],
  [11,8], [15,9], [14,10], [17,11], [6,12], [31,13], [25,14], [29,15], [32,16]
].map(([portrait,standing,role]) => ({
  group:'princess', portrait:'images/cast/p'+portrait+'.webp',
  icon:'images/cast/icon-'+standing+'.webp',
  standing:'images/cast/royal-'+standing+'.webp', role:role || '',
  name:'', introduction:'', voice:'', profile:'', sns:'', x:'', fanGroup:''
}));
for (const portrait of [4,16,21,22,28]) {
  profiles.push({group:'princess',portrait:'images/cast/p'+portrait+'.webp',icon:'images/cast/face-p'+portrait+'.webp',name:'',standing:'',role:'',introduction:'',voice:'',profile:'',sns:'', x:'', fanGroup:''});
}
// ポスター上の王子様役。正式名簿に合わせて変更できます。
for (const portrait of [35,2,3,5,7,8,12,13,19,20,23,26,27,34]) {
  profiles.push({group:'prince',portrait:'images/cast/p'+portrait+'.webp',icon:'images/cast/face-p'+portrait+'.webp',standing:'',role:'',name:'',introduction:'',voice:'',profile:'',sns:'', x:'', fanGroup:''});
}
Object.assign(profiles[0], {
  x:'https://x.com/43h7__?s=21',
  fanGroup:'https://vrchat.com/home/group/grp_50ab3901-0a4d-4817-893f-a79de27a8afb',
  name:'朝日奈', roman:'Asahina', posePrefix:'asahina',
  standing:'images/cast/asahina-heart.webp',
  poses:[
    ['heart','ハート'], ['ribbon','リボン'], ['wink','ウインク']
  ]
});
Object.assign(profiles.find(person => person.portrait === 'images/cast/p35.webp'), {
  icon:'images/cast/icon-17.webp',
  displayTitle:'銀の王冠の王子様', posePrefix:'silver-prince', standing:'images/cast/silver-prince-gaze.webp',
  poses:[['gaze','まなざし'],['arms','腕組み'],['dream','伏し目']]
});
const palaceContent = {
  cast:profiles,
  news:[{date:'2026-11-22',category:'サイト更新',title:'王宮の肖像画廊を模様替えしました。'}],
  gallery:[
  {
    "image": "images/gallery/memory-1.webp",
    "title": "お茶会の思い出　1"
  },
  {
    "image": "images/gallery/memory-2.webp",
    "title": "お茶会の思い出　2"
  },
  {
    "image": "images/gallery/memory-3.webp",
    "title": "お茶会の思い出　3"
  },
  {
    "image": "images/gallery/memory-4.webp",
    "title": "お茶会の思い出　4"
  },
  {
    "image": "images/gallery/memory-5.webp",
    "title": "お茶会の思い出　5"
  }
]
};
