# EUPHORIA
HTML・CSS・JavaScriptで動作する静的サイトです。ビルドや外部フォントは不要です。

## GitHub Pages
ZIPを展開し、euphoria フォルダの **中身** を公開リポジトリのルートへ配置します。Settings → Pages → Deploy from a branch で main / (root) を選択します。プロジェクトサイトのサブパスでも利用できます。ローカルでは index.html を開いて確認できます。

## 更新する場所
- index.html — 王宮のご案内、開催の流れ、規約とFAQ
- css/style.css — 配色、レイアウト、扉・カーテン・星・歓迎リボンの演出
- js/content.js — キャスト、日程、ニュース、画廊
- js/main.js — 画面操作、日程計算、写真拡大
- images/ornaments/checks.webp・frame.webp — 淡い水色とピンクの両扉に重ねるチェック柄と飾り枠
- images/cast/ — 肖像、任意の全身画像、オリジナルロゴ
- images/gallery/ — 集合ポスター・イベント挿絵・告知
- images/ornaments/ — 銀細工の装飾。メインの枠は images/gallery/concept.webp の周縁を再利用
- images/castle/ — 追加の王宮背景用

## キャスト
group は掲載区分（princess＝女性キャスト、prince＝男性キャスト）です。初期の区分はポスターの衣装・役柄を元にした仮配置です。運営名簿で確認し更新してください。新規メンバーは profiles に下記と同じ形式で追加します。
```js
profiles.push({group:'princess',portrait:'images/cast/portrait.webp',standing:'images/cast/full.webp',name:'表示名',role:'',introduction:'キャラクター紹介',voice:'声の特徴',profile:'プロフィール',x:'',fanGroup:''});
```
各キャストの x に本人のXプロフィールURL、fanGroup に本人のファングループURLを登録します。登録済みのリンクがそのキャストの紹介に表示されます。未記入の項目は表示されません。立ち絵を省略すると詳細にも肖像が表示されます。集合ポスターは images/gallery/cast.webp を差し替えてください。

## 日程・ニュース
開催日時・出勤キャストは公式Xで告知します。サイトの日程更新は不要です。
news には date（YYYY-MM-DD）、category、title を追加します。配信日から14日間 NEW が付きます。
gallery は image と title の組で追加します。公開前に日程・名簿・SNSを運営資料と照合してください。
